//Numpy array shape [2]
//Min 0.343750000000
//Max 0.562500000000
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[2];
#else
bias5_t b5[2] = {0.34375, 0.56250};
#endif

#endif
